package com.khainv9.tracnghiem.list;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.google.android.flexbox.FlexboxLayout;
import com.khainv9.tracnghiem.R;


public class ListDapAn extends ListMini {

    String[] dapAn;
    ItemDapAnRow[] dapAn1s;

    public ListDapAn(ViewGroup vg, String[] dapAn) {
        super(vg);
        this.dapAn = dapAn;
        dapAn1s = new ItemDapAnRow[dapAn.length];
    }

    @Override
    public VH createItem(int i, LayoutInflater inflater) {
        return new VH(inflater.inflate(R.layout.item_list_dap_an, null));
    }

    @Override
    public int getNumber() {
        return dapAn.length;
    }

    @Override
    public void update(int i) {
        FlexboxLayout ll = (FlexboxLayout) getMiniVH(i).item;
        dapAn1s[i] = new ItemDapAnRow(ll, dapAn[i]);
        dapAn1s[i].create();
    }

    public String[] getListDapAn1() {
        String[] all = new String[dapAn1s.length];
        for (int i = 0; i < dapAn1s.length; i++) all[i] = dapAn1s[i].getDapAn();
        return all;
    }
    public String[] getListDapAn2() {
        String[] all = new String[dapAn1s.length];
        for (int i = 0; i < dapAn1s.length; i++) all[i] = dapAn1s[i].getDapAn();
        return all;
    }
    public String[] getListDapAn3() {
        String[] all = new String[dapAn1s.length];
        for (int i = 0; i < dapAn1s.length; i++) all[i] = dapAn1s[i].getDapAn();
        return all;
    }

}
