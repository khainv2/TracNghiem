package com.khainv9.tracnghiem.models;

import org.msgpack.annotation.Message;

import java.util.Random;


@Message
public class DeThi {

    public static final String A = "A", B = "B", C = "C", D = "D", E = "E", NOT = "";

    public int id;
    public int maBaiThi;
    public String maDeThi;
    public String[] dapAnPhan1;
    public String[] dapAnPhan2;
    public String[] dapAnPhan3;

    public DeThi() {
    }

    public DeThi(int maBaiThi, int soCauPhan1, int soCauPhan2, int soCauPhan3) {
        this.id = new Random().nextInt();
        this.maBaiThi = maBaiThi;
        this.maDeThi = "";

        this.dapAnPhan1 = new String[soCauPhan1];
        this.dapAnPhan2 = new String[soCauPhan2];
        this.dapAnPhan3 = new String[soCauPhan3];

        for (int i = 0; i < dapAnPhan1.length; i++) this.dapAnPhan1[i] = NOT;
        for (int i = 0; i < dapAnPhan2.length; i++) this.dapAnPhan2[i] = NOT;
        for (int i = 0; i < dapAnPhan3.length; i++) this.dapAnPhan3[i] = NOT;
    }

    public DeThi(int id, int maBaiThi, String maDeThi, int soCauPhan1, int soCauPhan2, int soCauPhan3) {
        this.id = id;
        this.maBaiThi = maBaiThi;
        this.maDeThi = maDeThi;

        this.dapAnPhan1 = new String[soCauPhan1];
        this.dapAnPhan2 = new String[soCauPhan2];
        this.dapAnPhan3 = new String[soCauPhan3];

        for (int i = 0; i < dapAnPhan1.length; i++) this.dapAnPhan1[i] = NOT;
        for (int i = 0; i < dapAnPhan2.length; i++) this.dapAnPhan2[i] = NOT;
        for (int i = 0; i < dapAnPhan3.length; i++) this.dapAnPhan3[i] = NOT;
    }


}
