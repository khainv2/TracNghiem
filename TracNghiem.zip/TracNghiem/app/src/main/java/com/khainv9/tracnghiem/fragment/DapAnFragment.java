package com.khainv9.tracnghiem.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.khainv9.tracnghiem.R;

import com.khainv9.tracnghiem.list.ListDapAn;
import com.khainv9.tracnghiem.list.ListNumber;


public class DapAnFragment extends Fragment {

    public static final String ARG_DAP_AN_1 = "DapAnP1";
    public static final String ARG_DAP_AN_2 = "DapAnP2";
    public static final String ARG_DAP_AN_3 = "DapAnP3";
    ListDapAn listDapAn;

    public static DapAnFragment create(String[] dapAnPhan1, String[] dapAnPhan2, String[] dapAnPhan3) {
        DapAnFragment dapAnFragment = new DapAnFragment();
        Bundle arg = new Bundle();
        if (dapAnPhan1 != null) arg.putStringArray(ARG_DAP_AN_1, dapAnPhan1);
        if (dapAnPhan2 != null) arg.putStringArray(ARG_DAP_AN_2, dapAnPhan2);
        if (dapAnPhan3 != null) arg.putStringArray(ARG_DAP_AN_3, dapAnPhan3);
        dapAnFragment.setArguments(arg);
        return dapAnFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.screen_dap_an, container, false);
        String[] dapAn1 = getArguments().getStringArray(ARG_DAP_AN_1);
        String[] dapAn2 = getArguments().getStringArray(ARG_DAP_AN_2);
        String[] dapAn3 = getArguments().getStringArray(ARG_DAP_AN_3);

        String[] dapAn = new String[dapAn1.length + dapAn2.length + dapAn3.length];
        System.arraycopy(dapAn1, 0, dapAn, 0, dapAn1.length);
        System.arraycopy(dapAn2, 0, dapAn, dapAn1.length, dapAn2.length);
        System.arraycopy(dapAn3, 0, dapAn, dapAn1.length + dapAn2.length, dapAn3.length);

        new ListNumber((ViewGroup) v.findViewById(R.id.ll1), dapAn.length, 1).create();
        listDapAn = new ListDapAn((ViewGroup) v.findViewById(R.id.ll2), dapAn);
        listDapAn.create();
        return v;
    }

    public String[] getListDapAn1() {
        return listDapAn.getListDapAn1();
    }
    public String[] getListDapAn2() {
        return listDapAn.getListDapAn2();
    }
    public String[] getListDapAn3() {
        return listDapAn.getListDapAn3();
    }
}
